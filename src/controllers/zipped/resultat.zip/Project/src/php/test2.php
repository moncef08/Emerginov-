<?php
function hello()
 {
  echo "Bonjour tout le monde !";
 }

hello(); 
?> 