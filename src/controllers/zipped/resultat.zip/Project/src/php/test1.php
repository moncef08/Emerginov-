<?php
include 'test2.php';
hello();

?>